'''Python interface to cppEDM github.com/SugiharaLab/cppEDM'''

from .pyEDM import *
